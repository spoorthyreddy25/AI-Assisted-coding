# Transaction Sorter

A simple web app that loads financial transactions from a CSV file and lets the user
sort them by **date** or **amount** in **ascending** or **descending** order.

## Features
- Upload `transactions.csv` using a file picker
- Parse and display transactions in a clean table
- Sort by **date** or **amount** with one click
- Works fully in the browser using vanilla HTML, CSS, and JavaScript