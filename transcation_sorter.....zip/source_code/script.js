// script.js
// Transaction Sorter
// Loads transactions from a CSV file and lets the user sort by date or amount.

/**
 * Global array to hold all loaded transactions.
 * Each item has shape:
 * {
 *   date: string,
 *   description: string,
 *   category: string,
 *   amount: number
 * }
 */
let transactions = [];

document.addEventListener("DOMContentLoaded", () => {
	const fileInput = document.getElementById("fileInput");
	const sortBtn = document.getElementById("sortBtn");
	const sortField = document.getElementById("sortField");
	const sortOrder = document.getElementById("sortOrder");

	// When user selects a CSV file
	fileInput.addEventListener("change", handleFileSelect);

	// When user clicks the Sort button
	sortBtn.addEventListener("click", sortAndRender);

	// Extra UX: if data is already loaded, changing dropdowns will
	// immediately re‑sort the table.
	sortField.addEventListener("change", () => {
		if (transactions.length) sortAndRender();
	});
	sortOrder.addEventListener("change", () => {
		if (transactions.length) sortAndRender();
	});
});

/**
 * Handle CSV file selection.
 * Reads the file as text, parses it, and renders the table.
 */
function handleFileSelect(event) {
	const file = event.target.files[0];
	if (!file) return;

	const reader = new FileReader();

	reader.onload = (e) => {
		const text = e.target.result;
		transactions = parseCSV(text);
		renderTable(transactions);
	};

	reader.readAsText(file);
}

/**
 * Very small CSV parser for simple CSV (no quoted commas).
 * Assumes header like: Date,Description,Category,Amount
 */
function parseCSV(text) {
	const lines = text.trim().split(/\r?\n/);

	// If there is no data (only header or empty), return empty array
	if (lines.length <= 1) return [];

	// Read header and normalize to lowercase (so "Date" or "date" both work)
	const header = lines[0].split(",").map(h => h.trim().toLowerCase());

	const dateIndex = header.indexOf("date");
	const descIndex = header.indexOf("description");
	const catIndex = header.indexOf("category");
	const amtIndex = header.indexOf("amount");

	return lines.slice(1).map(line => {
		const cols = line.split(",").map(c => c.trim());

		return {
			date: cols[dateIndex] || "",
			description: cols[descIndex] || "",
			category: cols[catIndex] || "",
			amount: parseFloat(cols[amtIndex]) || 0
		};
	});
}

/**
 * Sort the current transactions according to UI selections
 * and render the sorted table.
 */
function sortAndRender() {
	if (!transactions.length) return;

	const field = document.getElementById("sortField").value;  // "date" or "amount"
	const order = document.getElementById("sortOrder").value;  // "asc" or "desc"
	const multiplier = order === "asc" ? 1 : -1;

	// Copy array so we don't modify the original order
	const sorted = [...transactions].sort((a, b) => {
		if (field === "date") {
			// Convert to timestamps for comparison
			const da = new Date(a.date).getTime();
			const db = new Date(b.date).getTime();
			return (da - db) * multiplier;
		} else {
			// Sort by numeric amount
			return (a.amount - b.amount) * multiplier;
		}
	});

	renderTable(sorted);
}

/**
 * Render an array of transaction objects into the HTML table body.
 */
function renderTable(data) {
	const tbody = document.querySelector("#transactionsTable tbody");
	tbody.innerHTML = "";

	data.forEach(tx => {
		const tr = document.createElement("tr");

		const tdDate = document.createElement("td");
		tdDate.textContent = tx.date;

		const tdDesc = document.createElement("td");
		tdDesc.textContent = tx.description;

		const tdCat = document.createElement("td");
		tdCat.textContent = tx.category;

		const tdAmt = document.createElement("td");
		tdAmt.textContent = tx.amount.toFixed(2);

		tr.appendChild(tdDate);
		tr.appendChild(tdDesc);
		tr.appendChild(tdCat);
		tr.appendChild(tdAmt);

		tbody.appendChild(tr);
	});
}